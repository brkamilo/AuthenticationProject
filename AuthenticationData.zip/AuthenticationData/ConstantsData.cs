﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AuthenticationData
{
    public static class ConstantsData
    {
        public static string ConnectionString_Key = "AuthenticationEntities";
        public static string ModelName = "AuthenticationModel";
        public static string ConnectionStringModel;
        public static string ConnectionStringSimple;

        static ConstantsData()
        {
            ConnectionStringSettings connectionSettings = DataHelpers.GetConfigConnectionString(ConnectionString_Key);
            ConnectionStringModel = DataHelpers.GetModelConnectionString(ModelName, connectionSettings);
            ConnectionStringSimple = DataHelpers.GetSimpleConnectionString(ConnectionStringModel);
        }
    }
}
