﻿using AuthenticationData.Properties;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Entity.Core.EntityClient;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AuthenticationData
{
    public static class DataHelpers
    {
        public static ConnectionStringSettings GetConfigConnectionString(string key)
        {
            ConnectionStringSettings connectionString;
            try
            {
                connectionString = ConfigurationManager.ConnectionStrings[key];
            }
            catch
            {
                throw new Exception(string.Format("No se encontró la conexión '{0}'", key));
            }
            return connectionString;
        }
        public static DataTable GetDataTable(string command, string tableName, string connectionString)
        {
            DataSet data = GetDataSet(command, connectionString);
            DataTable result = data.Tables[0];
            result.TableName = tableName;
            return result;
        }
        public static DataSet GetDataSet(string strCommand, string connectionString)
        {
            DataSet result = new DataSet();
            try
            {
                // Se crea la conexión
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    SqlCommand command = new SqlCommand();
                    command.CommandTimeout = Settings.Default.SqlCommandTimeoutSeconds;
                    command.CommandText = strCommand;
                    command.CommandType = CommandType.Text;
                    command.Connection = connection;
                    SqlDataAdapter da = new SqlDataAdapter(command);
                    da.Fill(result);
                    da.Dispose();
                }
            }
            catch (Exception exc)
            {
                throw new Exception("Error GetDataTable", exc);
            }
            return result;
        }

        public static string GetModelConnectionString(string modelName, ConnectionStringSettings connectionSettings)
        {
            string connectionString = connectionSettings.ConnectionString;
            if (!connectionString.Contains(modelName))
            {
                EntityConnectionStringBuilder csb = new EntityConnectionStringBuilder();
                csb.Metadata = string.Format("res://*/{0}.csdl|res://*/{0}.ssdl|res://*/{0}.msl", modelName);
                csb.Provider = connectionSettings.ProviderName;
                csb.ProviderConnectionString = connectionString;
                connectionString = csb.ToString();
            }
            return connectionString;
        }
        public static string GetSimpleConnectionString(string modelConnectionString)
        {
            string connectionString = new EntityConnectionStringBuilder(modelConnectionString).ProviderConnectionString;
            return connectionString;
        }


        public static void ExecuteCommand(string strCommand, string connectionString)
        {
            try
            {
                // Se crea la conexión
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    SqlCommand command = new SqlCommand();
                    command.CommandTimeout = Settings.Default.SqlCommandTimeoutSeconds;
                    command.CommandText = strCommand;
                    command.CommandType = CommandType.Text;
                    command.Connection = connection;
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception exc)
            {
                throw new Exception("Error GetDataTable", exc);
            }
        }

        
    }
}
