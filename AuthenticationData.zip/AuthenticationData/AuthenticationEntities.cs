﻿using AuthenticationData.Properties;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AuthenticationData
{
    public partial class AuthenticationEntities
    {
        public AuthenticationEntities(string connectionString)
           : base(connectionString)
        {
            this.Database.CommandTimeout = Settings.Default.SqlCommandTimeoutSeconds;
            this.Configuration.LazyLoadingEnabled = false;
        }
    }
}
